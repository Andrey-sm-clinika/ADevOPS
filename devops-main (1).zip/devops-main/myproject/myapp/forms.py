# In <app_name>/forms.py
