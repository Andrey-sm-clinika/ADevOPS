# DevOps practice repo

To start the project, you must provide the missing database information in:
- .env
